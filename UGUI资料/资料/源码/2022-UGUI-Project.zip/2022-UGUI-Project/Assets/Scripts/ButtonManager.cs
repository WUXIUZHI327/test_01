using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonManager : MonoBehaviour
{

    public void OnButtonClick()
    {
        print("ButtonClick");
    }

    public void OnButtonClick(int i) 
    {
        print("ButtonClick+" + i);
    }

}
